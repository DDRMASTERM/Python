animals=['Giraffe', 'Lion', 'Rhinoceros']

for n in animals:
	print(f"The {n} can be found in Africa.")
print("All these animals can be found in Africa")
