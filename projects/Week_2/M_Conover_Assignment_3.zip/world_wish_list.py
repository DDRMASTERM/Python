world=['Tokyo', 'Hong Kong', 'London', 'Berlin', 'Sao Paulo']

print(world)
print(sorted(world))
print(sorted(world, reverse=True))

world.reverse()
print(world)

world.reverse()
print(world)

world.sort()
print(world)

world.sort(reverse=True)
print(world)
