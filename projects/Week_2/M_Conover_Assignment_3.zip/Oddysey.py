odd=list(range(1, 20, 2))

for n in odd:
	print(n)
