##Matthew Conover
## assignment 5-6
## IS 3750


age = int(input("How old are you? "))

if age < 2:
	print("You're a baby, waaaaaaaaaa!")
elif age < 4:
	print("You're a toddler, walk along.")
elif age < 13:
	print("You're just a kid, hope life is not a nightmare.")
elif age < 20:
	print("You're a teenager, it's totally not a phase guys.")
elif age < 65:
	print("You're an adult, act like it.")
elif age >= 65:
	print("You're an elder, Okay Boomer")
