# Matthew Conover
# IS 3750
# Assignment 6-1

# defining the dictionary
person = { "first_name" : "Kayla",
			"last_name" : "Conover",
			"age" : 25,
			"city" : "Idaho Falls" }

# Print items in the dictionary
for k,v in person.items():
	print(f"{k}: {v}")

