#Matthew Conover
#Exercise 2.4
#Print a name in lower case, upper case, and title case
name="john Cena!"
print(name.lower())
print(name.title())
print(name.upper())
