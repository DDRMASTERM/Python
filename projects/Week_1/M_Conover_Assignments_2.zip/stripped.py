#Matthew Conover
#Excercise 2.7
#Store a name with \t and \n and demonstrate each strip type
name="\n\tLuigi\n"
print(name.rstrip())
print(name.lstrip())
print(name.strip())
