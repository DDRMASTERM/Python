#Matthew Conover
#Excercise 2.5
#Print a famous name and a famous quote
print('Bruce Lee once declared, "I fear not the man who has practiced 10,000 kicks once, but I fear the man who has practiced one kick 10,000 times."')
