#Matthew Conover
#Excercise 2.9
#store and then print your favorite number in a message
fav_num=42
print("The Answer to the Great Question...\n"+
"Of Life, the Universe and Everything...\n"
"Is..."+str(fav_num)+".")
